package Usuarios;

@FunctionalInterface
public interface AccionBotonTabla {
    void ejecutar(int id);
}

