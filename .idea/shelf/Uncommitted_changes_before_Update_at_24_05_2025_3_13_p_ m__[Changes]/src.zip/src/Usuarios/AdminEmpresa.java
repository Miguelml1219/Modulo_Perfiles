package Usuarios;

public class AdminEmpresa {
}
